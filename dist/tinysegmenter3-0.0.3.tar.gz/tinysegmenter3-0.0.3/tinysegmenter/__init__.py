from .tinysegmenter import TinySegmenter
